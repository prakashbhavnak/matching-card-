import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Timer,
  Heart,
  Star,
  Moon,
  Sun,
  Music,
  Camera,
  Coffee,
  Rocket,
  RefreshCw,
  Trophy,
  Volume2,
  VolumeX,
} from 'lucide-react';

type Card = {
  id: number;
  icon: React.ReactNode;
  isFlipped: boolean;
  isMatched: boolean;
  value: string;
};

const icons = [
  { icon: <Heart size={32} />, value: 'heart' },
  { icon: <Star size={32} />, value: 'star' },
  { icon: <Moon size={32} />, value: 'moon' },
  { icon: <Sun size={32} />, value: 'sun' },
  { icon: <Music size={32} />, value: 'music' },
  { icon: <Camera size={32} />, value: 'camera' },
  { icon: <Coffee size={32} />, value: 'coffee' },
  { icon: <Rocket size={32} />, value: 'rocket' },
];

export default function Game() {
  const navigate = useNavigate();
  const [cards, setCards] = useState<Card[]>([]);
  const [moves, setMoves] = useState(0);
  const [bestScore, setBestScore] = useState<number>(
    parseInt(localStorage.getItem('bestScore') || '0')
  );
  const [timer, setTimer] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.3;
      audioRef.current.loop = true;
      if (!isMuted) {
        audioRef.current.play().catch(() => {
          // Autoplay was prevented, user needs to interact first
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isMuted]);

  const initializeGame = () => {
    const duplicatedIcons = [...icons, ...icons];
    const shuffledCards = duplicatedIcons
      .sort(() => Math.random() - 0.5)
      .map((item, index) => ({
        id: index,
        icon: item.icon,
        isFlipped: false,
        isMatched: false,
        value: item.value,
      }));
    setCards(shuffledCards);
    setMoves(0);
    setTimer(0);
    setIsRunning(false);
    setFlippedCards([]);
  };

  const handleCardClick = (id: number) => {
    if (
      isChecking ||
      flippedCards.includes(id) ||
      cards[id].isMatched ||
      flippedCards.length === 2
    ) {
      return;
    }

    if (!isRunning) {
      setIsRunning(true);
      if (audioRef.current && !isMuted) {
        audioRef.current.play().catch(() => {
          // Handle autoplay restriction
        });
      }
    }

    const newCards = [...cards];
    newCards[id].isFlipped = true;
    setCards(newCards);

    setFlippedCards((prev) => {
      const newFlipped = [...prev, id];

      if (newFlipped.length === 2) {
        setIsChecking(true);
        setMoves((prev) => prev + 1);

        const [first, second] = newFlipped;
        if (cards[first].value === cards[second].value) {
          setTimeout(() => {
            const matchedCards = [...cards];
            matchedCards[first].isMatched = true;
            matchedCards[second].isMatched = true;
            setCards(matchedCards);
            setFlippedCards([]);
            setIsChecking(false);

            // Check if game is complete
            if (matchedCards.every((card) => card.isMatched)) {
              setIsRunning(false);
              if (!bestScore || moves + 1 < bestScore) {
                setBestScore(moves + 1);
                localStorage.setItem('bestScore', (moves + 1).toString());
              }
              navigate('/end', { 
                state: { 
                  moves: moves + 1, 
                  time: timer,
                  bestScore: !bestScore || moves + 1 < bestScore ? moves + 1 : bestScore
                }
              });
            }
          }, 500);
        } else {
          setTimeout(() => {
            const resetCards = [...cards];
            resetCards[first].isFlipped = false;
            resetCards[second].isFlipped = false;
            setCards(resetCards);
            setFlippedCards([]);
            setIsChecking(false);
          }, 1000);
        }
      }

      return newFlipped;
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs
      .toString()
      .padStart(2, '0')}`;
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4 sm:p-8">
      <audio
        ref={audioRef}
        src="https://assets.mixkit.co/music/preview/mixkit-game-show-fun-668.mp3"
      />
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-4 sm:mb-0">
              Memory Game
            </h1>
            <div className="flex gap-4 items-center">
              <button
                onClick={toggleMute}
                className="text-gray-600 hover:text-gray-800 transition-colors duration-200"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
              </button>
              <div className="flex items-center gap-2">
                <Timer className="text-gray-600" />
                <span className="text-xl font-semibold text-gray-700">
                  {formatTime(timer)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Trophy className="text-gray-600" />
                <span className="text-xl font-semibold text-gray-700">
                  {moves} Moves
                </span>
              </div>
              <button
                onClick={initializeGame}
                className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg p-2 transition-colors duration-200"
                title="Restart Game"
              >
                <RefreshCw size={24} />
              </button>
            </div>
          </div>

          {bestScore > 0 && (
            <div className="text-center mb-4 text-gray-700">
              Best Score: {bestScore} moves
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {cards.map((card) => (
              <div
                key={card.id}
                className={`aspect-square cursor-pointer perspective-1000 ${
                  card.isMatched ? 'opacity-50' : ''
                }`}
                onClick={() => handleCardClick(card.id)}
              >
                <div
                  className={`relative w-full h-full transition-transform duration-500 transform-style-3d ${
                    card.isFlipped ? 'rotate-y-180' : ''
                  }`}
                >
                  <div className="absolute w-full h-full bg-indigo-600 rounded-xl flex items-center justify-center backface-hidden shadow-md">
                    <div className="text-4xl text-white">?</div>
                  </div>
                  <div className="absolute w-full h-full bg-white rounded-xl flex items-center justify-center backface-hidden rotate-y-180 shadow-md">
                    <div className="text-indigo-600">{card.icon}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}