import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Trophy, Timer, RefreshCw, Home } from 'lucide-react';

export default function End() {
  const navigate = useNavigate();
  const location = useLocation();
  const { moves, time, bestScore } = location.state || { moves: 0, time: 0, bestScore: 0 };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-8 text-center">
        <Trophy className="w-20 h-20 text-yellow-400 mx-auto mb-6" />
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Congratulations!</h1>
        <p className="text-xl text-gray-600 mb-8">You've completed the game!</p>

        <div className="space-y-4 mb-8">
          <div className="bg-indigo-50 p-4 rounded-xl">
            <div className="flex items-center justify-center gap-3 text-xl font-semibold text-gray-800">
              <Trophy className="w-6 h-6 text-indigo-600" />
              <span>Moves: {moves}</span>
            </div>
          </div>

          <div className="bg-indigo-50 p-4 rounded-xl">
            <div className="flex items-center justify-center gap-3 text-xl font-semibold text-gray-800">
              <Timer className="w-6 h-6 text-indigo-600" />
              <span>Time: {formatTime(time)}</span>
            </div>
          </div>

          {bestScore === moves && (
            <div className="bg-yellow-50 p-4 rounded-xl">
              <p className="text-yellow-800 font-semibold">New Best Score! 🎉</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/game')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-xl shadow-lg transition-all duration-200 flex items-center justify-center gap-2"
          >
            <RefreshCw size={20} />
            Play Again
          </button>
          <button
            onClick={() => navigate('/')}
            className="bg-gray-600 hover:bg-gray-700 text-white font-semibold px-6 py-3 rounded-xl shadow-lg transition-all duration-200 flex items-center justify-center gap-2"
          >
            <Home size={20} />
            Home
          </button>
        </div>
      </div>
    </div>
  );
}