import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Trophy, Timer, PlayCircle } from 'lucide-react';

export default function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl p-8">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <Brain className="w-20 h-20 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Memory Match</h1>
          <p className="text-xl text-gray-600 mb-8">
            Test your memory and concentration with this classic card matching game!
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-indigo-50 p-6 rounded-xl">
              <Trophy className="w-8 h-8 text-indigo-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Track Scores</h3>
              <p className="text-gray-600">Compete with yourself and beat your best score</p>
            </div>
            
            <div className="bg-indigo-50 p-6 rounded-xl">
              <Timer className="w-8 h-8 text-indigo-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Race Against Time</h3>
              <p className="text-gray-600">Complete the game as quickly as you can</p>
            </div>
            
            <div className="bg-indigo-50 p-6 rounded-xl">
              <Brain className="w-8 h-8 text-indigo-600 mx-auto mb-3" />
              <h3 className="font-semibold text-gray-800 mb-2">Train Your Brain</h3>
              <p className="text-gray-600">Improve your memory and concentration</p>
            </div>
          </div>
          
          <button
            onClick={() => navigate('/game')}
            className="bg-indigo-600 hover:bg-indigo-700 text-white text-xl font-semibold px-8 py-4 rounded-xl shadow-lg transition-all duration-200 flex items-center justify-center gap-3 w-full"
          >
            <PlayCircle size={24} />
            Start Game
          </button>
        </div>
      </div>
    </div>
  );
}